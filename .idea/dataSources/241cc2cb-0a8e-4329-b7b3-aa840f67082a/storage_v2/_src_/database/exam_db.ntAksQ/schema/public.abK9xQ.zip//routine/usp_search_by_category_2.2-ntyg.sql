create procedure usp_search_by_category_2(IN category character varying)
    language plpgsql
as
$$
BEGIN
    -- Clear previous results from the table
    TRUNCATE TABLE search_results;

    -- Insert new results into the table
    INSERT INTO search_results (
		"name",
		release_year,
		rating,
		category_name,
		publisher_name,
		min_players,
		max_players
	)
    SELECT
        bg."name",
        bg.release_year,
        bg.rating,
        c."name" AS category_name,
        p."name" AS publisher_name,
        CONCAT(pr.min_players, ' people'),
        CONCAT(pr.max_players, ' people')
    FROM
		board_games AS bg
    JOIN
		publishers AS p
		ON
		bg.publisher_id = p.id
    JOIN
		categories AS c
		ON
		bg.category_id = c."id"
    JOIN
		players_ranges AS pr
		ON
		bg.players_range_id = pr."id"
    WHERE
		c."name" = category
    ORDER BY
		publisher_name,
		release_year DESC;
END;
$$;

alter procedure usp_search_by_category_2(varchar) owner to postgres;

