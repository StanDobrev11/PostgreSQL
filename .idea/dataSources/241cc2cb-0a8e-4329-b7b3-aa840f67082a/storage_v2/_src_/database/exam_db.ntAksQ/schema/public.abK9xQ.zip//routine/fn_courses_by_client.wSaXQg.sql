create function fn_courses_by_client(phone_num character varying) returns integer
    language plpgsql
as
$$
DECLARE
    number_of_courses INT;
BEGIN
    SELECT COUNT(*)
    INTO number_of_courses
    FROM courses
    JOIN clients ON courses.client_id = clients.id
    WHERE clients.phone_number = phone_num;

    RETURN COALESCE(number_of_courses, 0);
END;
$$;

alter function fn_courses_by_client(varchar, out integer) owner to postgres;

