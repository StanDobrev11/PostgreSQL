create procedure udp_modify_account(IN address_street character varying, IN address_town character varying)
    language plpgsql
as
$$
BEGIN
    UPDATE accounts
    SET job_title = CONCAT('(Remote)', ' ', job_title)
    WHERE accounts.id =
          (SELECT account_id
           FROM addresses
                    JOIN accounts ON addresses.account_id = accounts.id
           WHERE street = address_street
             AND town = address_town)
      AND NOT job_title LIKE '(Remote) %';
END
$$;

alter procedure udp_modify_account(varchar, varchar) owner to postgres;

