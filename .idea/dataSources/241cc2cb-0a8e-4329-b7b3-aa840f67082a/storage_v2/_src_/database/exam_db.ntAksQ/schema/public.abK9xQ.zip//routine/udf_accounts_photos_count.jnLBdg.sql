create function udf_accounts_photos_count(account_username character varying) returns integer
    language plpgsql
as
$$
DECLARE
    photos_count INT;
BEGIN
    SELECT
        count(accounts_photos)
    INTO photos_count
    FROM
        accounts
        JOIN accounts_photos ON accounts.id = accounts_photos.account_id
    WHERE username = account_username;

    RETURN photos_count;
END;
$$;

alter function udf_accounts_photos_count(varchar) owner to postgres;

