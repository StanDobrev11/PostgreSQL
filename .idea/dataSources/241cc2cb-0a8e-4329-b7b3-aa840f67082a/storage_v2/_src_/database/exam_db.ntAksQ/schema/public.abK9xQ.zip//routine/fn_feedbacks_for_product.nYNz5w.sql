create function fn_feedbacks_for_product(product_name character varying)
    returns TABLE(customer_id integer, customer_name character varying, feedback_description character varying, feedback_rate numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT
        customers.id as customer_id,
        customers.first_name as customer_name,
        feedbacks.description as feedback_description,
        feedbacks.rate as feedback_rate
    FROM customers
    JOIN feedbacks ON customers.id = feedbacks.customer_id
    JOIN products ON feedbacks.product_id = products.id
    WHERE
        products.name = product_name
    ORDER BY
        customer_id;

END
$$;

alter function fn_feedbacks_for_product(varchar) owner to postgres;

