create function fn_creator_with_board_games(target_first_name character varying) returns integer
    language plpgsql
as
$$
DECLARE
    total_games INT;
BEGIN
    SELECT count(board_game_id)
    INTO total_games
    FROM creators
             JOIN creators_board_games on creators.id = creators_board_games.creator_id
    WHERE first_name = target_first_name;

    RETURN total_games;
END;
$$;

alter function fn_creator_with_board_games(varchar, out integer) owner to postgres;

