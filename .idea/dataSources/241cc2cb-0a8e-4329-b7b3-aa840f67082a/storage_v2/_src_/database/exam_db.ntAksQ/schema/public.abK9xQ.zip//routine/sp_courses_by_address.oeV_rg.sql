create procedure sp_courses_by_address(IN address_name character varying)
    language plpgsql
as
$$
BEGIN
    TRUNCATE TABLE search_results;
    INSERT INTO search_results(
                               address_name,
                               full_name,
                               level_of_bill,
                               make,
                               condition,
                               category_name
    )
    SELECT addresses.name,
           clients.full_name,
           CASE
               WHEN courses.bill <= 20 THEN 'Low'
               WHEN courses.bill <= 30 THEN 'Medium'
               ELSE 'High'
               END         AS level_of_bill,
           cars.make,
           cars.condition,
           categories.name
    FROM addresses
             JOIN courses ON addresses.id = courses.from_address_id
             JOIN clients ON courses.client_id = clients.id
             JOIN cars ON courses.car_id = cars.id
             JOIN categories ON cars.category_id = categories.id
    WHERE addresses.name = address_name
    ORDER BY
        cars.make,
        clients.full_name;
END
$$;

alter procedure sp_courses_by_address(varchar) owner to postgres;

