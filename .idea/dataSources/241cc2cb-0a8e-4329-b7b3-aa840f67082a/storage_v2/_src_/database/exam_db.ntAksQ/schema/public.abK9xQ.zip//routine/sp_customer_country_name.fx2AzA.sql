create procedure sp_customer_country_name(IN customer_full_name character varying, OUT country_name character varying)
    language plpgsql
as
$$
BEGIN
    country_name :=
            (SELECT countries.name
             FROM countries
                      JOIN customers ON countries.id = customers.country_id
             WHERE
                 CONCAT(customers.first_name, ' ', customers.last_name) LIKE customer_full_name);
END
$$;

alter procedure sp_customer_country_name(varchar, out varchar) owner to postgres;

